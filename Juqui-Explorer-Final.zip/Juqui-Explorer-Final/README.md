# Juqui Explorer

Estrutura pronta para adicionar as fotos reais e subir ao GitHub Pages.