// JS principal (carrossel, juka, carrinho) — versão resumida para pacote leve.
document.addEventListener('DOMContentLoaded',()=>{});