// ============ CONFIG CLIMA ============
// Pegue uma chave gratuita em: https://openweathermap.org/ e coloque aqui:
const WEATHER_API_KEY = "SUA_CHAVE_AQUI"; // TROQUE
const WEATHER_LAT = JUQUITIBA_LAT;
const WEATHER_LNG = JUQUITIBA_LNG;

// ============ CLIMA ============

async function carregarClima() {
  const widget = document.getElementById("weather-widget");
  if (!widget || !WEATHER_API_KEY || WEATHER_API_KEY === "SUA_CHAVE_AQUI") {
    if (widget) widget.textContent = "Configure a chave da API de clima em app.js para exibir o tempo em tempo real.";
    return;
  }

  widget.textContent = "Carregando clima de Juquitiba...";

  try {
    const url =
      `https://api.openweathermap.org/data/2.5/weather?lat=${WEATHER_LAT}&lon=${WEATHER_LNG}&appid=${WEATHER_API_KEY}&units=metric&lang=pt_br`;

    const res = await fetch(url);
    if (!res.ok) throw new Error("Erro ao buscar clima");
    const data = await res.json();

    const temp = Math.round(data.main.temp);
    const cond = data.weather?.[0]?.description || "";
    const hum = data.main.humidity;
    const feels = Math.round(data.main.feels_like);

    widget.innerHTML = `
      🌤 <strong>${temp}°C</strong> • ${cond} <br />
      Sensação: ${feels}°C • Umidade: ${hum}% • Juquitiba, SP
    `;
  } catch (err) {
    widget.textContent = "Não foi possível carregar o clima agora.";
    console.error(err);
  }
}

// ============ LISTA DE PONTOS (PÁGINA PONTOS) ============

function montarListaPontos() {
  const lista = document.getElementById("lista-pontos");
  if (!lista) return; // não está nessa página

  lista.innerHTML = "";

  PONTOS_TURISTICOS.forEach((ponto) => {
    const article = document.createElement("article");
    article.className = "card";
    article.dataset.card = "true";
    article.dataset.category = ponto.categoria;

    const tipoLabel = tipoParaTexto(ponto.tipo);
    const wazeLink = gerarLinkWaze(ponto.lat, ponto.lng);

    article.innerHTML = `
      <div class="card-header">
        <h3 class="card-title">${ponto.nome}</h3>
        <span class="card-tag">${tipoLabel}</span>
      </div>
      <p class="card-body">${ponto.descricao}</p>
      <div class="card-meta">
        <div class="chip-row">
          <span class="chip">${ponto.bairro || "Juquitiba"}</span>
          <a class="chip" href="${wazeLink}" target="_blank" rel="noopener noreferrer">
            Abrir no Waze
          </a>
        </div>
        <span>Lat: ${ponto.lat.toFixed(3)} • Lng: ${ponto.lng.toFixed(3)}</span>
      </div>
    `;

    lista.appendChild(article);
  });
}

function tipoParaTexto(tipo) {
  const map = {
    cachoeira: "Cachoeira",
    trilha: "Trilha",
    pousada: "Pousada",
    pesqueiro: "Pesqueiro",
    "ponto-turistico": "Ponto turístico",
  };
  return map[tipo] || tipo;
}

function gerarLinkWaze(lat, lng) {
  return `https://waze.com/ul?ll=${lat},${lng}&navigate=yes`;
}

// ============ BUSCA & FILTRO SIMPLES (compartilhado) ============

document.addEventListener("input", (e) => {
  const alvo = e.target;
  if (!alvo.matches(".search-input")) return;

  const termo = alvo.value.toLowerCase();
  const cards = document.querySelectorAll("[data-card]");

  cards.forEach((card) => {
    const texto = (card.innerText || card.textContent).toLowerCase();
    card.style.display = texto.includes(termo) ? "block" : "none";
  });
});

document.addEventListener("click", (e) => {
  const botaoFiltro = e.target.closest(".filter-pill");
  if (!botaoFiltro) return;

  const categoria = botaoFiltro.dataset.filter;
  const cards = document.querySelectorAll("[data-card]");
  document.querySelectorAll(".filter-pill").forEach((b) => b.classList.remove("active"));
  botaoFiltro.classList.add("active");

  cards.forEach((card) => {
    if (categoria === "all") {
      card.style.display = "block";
    } else {
      card.style.display = card.dataset.category === categoria ? "block" : "none";
    }
  });
});

// ============ JUCA – MASCOTE AJUDA ============

function setupJuca() {
  const juca = document.getElementById("juca-widget");
  if (!juca) return;

  const bubble = juca.querySelector(".juca-bubble");
  const toggle = juca.querySelector(".juca-toggle");

  let aberto = false;

  const frases = [
    "Oi, eu sou o Juca! Clica em qualquer botão do Waze pra ir direto pro ponto 😉",
    "Dica: usa a busca pra achar trilha, cachoeira, pousada ou pesqueiro pelo nome.",
    "Vai pra cachoeira? Dá uma olhada no clima aqui em cima antes de sair 🌦"
  ];
  let idx = 0;

  function atualizarTexto() {
    const textoSpan = bubble.querySelector("p");
    textoSpan.textContent = frases[idx];
    idx = (idx + 1) % frases.length;
  }

  toggle.addEventListener("click", () => {
    aberto = !aberto;
    bubble.style.display = aberto ? "block" : "none";
    if (aberto) atualizarTexto();
  });
}

// ============ INICIALIZAÇÃO ============

document.addEventListener("DOMContentLoaded", () => {
  carregarClima();
  montarListaPontos();
  setupJuca();
});
