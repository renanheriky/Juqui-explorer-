// Coordenadas aproximadas de Juquitiba (ajuste se quiser)
const JUQUITIBA_LAT = -23.930;
const JUQUITIBA_LNG = -47.070;

// TROQUE PELOS DADOS REAIS DOS PONTOS
const PONTOS_TURISTICOS = [
  // 2 CACHOEIRAS
  {
    id: "cachoeira-1",
    tipo: "cachoeira",
    categoria: "natureza",
    nome: "NOME_DA_CACHOEIRA_1",
    descricao: "Descrição resumida da primeira cachoeira (acesso, tamanho da queda, poço para banho, etc.).",
    bairro: "Bairro / região",
    lat: -23.935,
    lng: -47.080
  },
  {
    id: "cachoeira-2",
    tipo: "cachoeira",
    categoria: "natureza",
    nome: "NOME_DA_CACHOEIRA_2",
    descricao: "Descrição resumida da segunda cachoeira.",
    bairro: "Bairro / região",
    lat: -23.920,
    lng: -47.065
  },

  // 2 TRILHAS
  {
    id: "trilha-1",
    tipo: "trilha",
    categoria: "natureza",
    nome: "NOME_DA_TRILHA_1",
    descricao: "Trilha com nível de dificuldade, tempo médio e visual principal.",
    bairro: "Bairro / região",
    lat: -23.940,
    lng: -47.060
  },
  {
    id: "trilha-2",
    tipo: "trilha",
    categoria: "natureza",
    nome: "NOME_DA_TRILHA_2",
    descricao: "Outra trilha, talvez mais leve/pesada, você define.",
    bairro: "Bairro / região",
    lat: -23.945,
    lng: -47.075
  },

  // 2 POUSADAS
  {
    id: "pousada-1",
    tipo: "pousada",
    categoria: "hospedagem",
    nome: "NOME_DA_POUSADA_1",
    descricao: "Pousada com café da manhã, proximidade de trilhas ou rios, perfil familiar/casal.",
    bairro: "Bairro / região",
    lat: -23.928,
    lng: -47.072
  },
  {
    id: "pousada-2",
    tipo: "pousada",
    categoria: "hospedagem",
    nome: "NOME_DA_POUSADA_2",
    descricao: "Outra pousada com características diferentes (mais rústica, mais simples, etc.).",
    bairro: "Bairro / região",
    lat: -23.932,
    lng: -47.068
  },

  // 2 PESQUEIROS
  {
    id: "pesqueiro-1",
    tipo: "pesqueiro",
    categoria: "lazer",
    nome: "NOME_DO_PESQUEIRO_1",
    descricao: "Pesqueiro com lagos de pesca esportiva, restaurante e estrutura para famílias.",
    bairro: "Bairro / região",
    lat: -23.938,
    lng: -47.085
  },
  {
    id: "pesqueiro-2",
    tipo: "pesqueiro",
    categoria: "lazer",
    nome: "NOME_DO_PESQUEIRO_2",
    descricao: "Outro pesqueiro, day use, quiosques, etc.",
    bairro: "Bairro / região",
    lat: -23.924,
    lng: -47.078
  },

  // Outros pontos turísticos (praça, mirante, etc.)
  {
    id: "ponto-1",
    tipo: "ponto-turistico",
    categoria: "outros",
    nome: "NOME_DE_OUTRO_PONTO_1",
    descricao: "Praça, mirante, ponto histórico ou outro atrativo da cidade.",
    bairro: "Bairro / região",
    lat: -23.931,
    lng: -47.071
  },
  {
    id: "ponto-2",
    tipo: "ponto-turistico",
    categoria: "outros",
    nome: "NOME_DE_OUTRO_PONTO_2",
    descricao: "Mais um ponto interessante para quem visita Juquitiba.",
    bairro: "Bairro / região",
    lat: -23.927,
    lng: -47.074
  }
];
